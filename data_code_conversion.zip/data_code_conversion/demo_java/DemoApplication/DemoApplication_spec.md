# DemoApplication Module Migration Specification

## Overview
The `DemoApplication` serves as the main module for a Cheque Processing System. Its primary responsibilities include user authentication, cheque processing (both single and batch), fraud detection, currency exchange, reporting, and administrative tools. It includes robust exception handling and additional modules for cheque security features such as encryption and signature verification. The module integrates several services, including external APIs, to provide a comprehensive banking solution.

---

## Inputs & Outputs

| **Method**                              | **Parameters**                         | **Return Type** | **Side Effects**                                                                                                                                               |
|------------------------------------------|-----------------------------------------|-----------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `main(String[] args)`                    | `String[] args`                         | `void`          | Initializes the Cheque Processing System and calls other service methods based on user input.                                                                  |
| `performLogin(Scanner scanner, UserService userService)` | `Scanner`, `UserService`               | `User`          | Authenticates the user by validating login credentials. Updates login attempt count.                                                                            |
| `processChequeBatch(Scanner scanner, ChequeProcessor chequeProcessor)` | `Scanner`, `ChequeProcessor`           | `void`          | Collects batch cheque details from the user, processes them sequentially, and updates cheque statuses.                                                         |
| `displayCurrencyExchangeMenu(Scanner scanner, CurrencyExchangeService currencyExchange)` | `Scanner`, `CurrencyExchangeService` | `void`          | Displays exchange rates and allows currency conversion. Updates exchange rate cache if expired.                                                                |
| `handleReportGeneration(Scanner scanner, ChequeHistoryManager chequeHistoryManager)` | `Scanner`, `ChequeHistoryManager`     | `void`          | Generates and displays cheque transaction reports for various timeframes.                                                                                       |
| `handleChequePrinting(Scanner scanner, ChequePrintingService chequePrintingService)` | `Scanner`, `ChequePrintingService`   | `void`          | Simulates cheque printing, displaying payee and amount according to user input.                                                                                |
| `handleChequeImageSubmission(...)`      | `<parameters not provided>`             | `void`          | Encrypts and signs the cheque image, then securely transmits it to a clearinghouse mock service. Generates audit logs.                                          |

---

## Business Rules

1. The system must enforce a maximum login retry limit for user authentication.
2. Currency exchange rates must be cached and invalidated after the specified expiry duration (CACHE_EXPIRY_MINUTES).
3. Fraud detection thresholds must be consistent across all cheque processing workflows.
4. Signature verification must be mandatory for each cheque before approval.
5. Cheques in batch processing must be handled sequentially with appropriate status updates at each step.
6. Administrative tools must restrict access to users with admin roles.
7. Error messages and exception handling must be user-friendly and logged appropriately.
8. Fallback mechanisms must be in place for external service failures, such as currency exchange APIs or cheque encryption services.
9. The cheque lifecycle must adhere strictly to the statuses outlined in the `ChequeStatus` enum.
10. Exception reports must log all cheque errors, including duplicates, bounced cheques, fraud, and unprocessable transactions.

---

## Data Structures

### `BatchCheque` (Class)
| **Field**         | **Type** |
|--------------------|----------|
| `accountNumber`    | `String` |
| `chequeNumber`     | `String` |
| `currency`         | `String` |
| `amount`           | `double` |
| `signature`        | `String` |

### `ChequeProcessor` (Class)
| **Field**                        | **Type**                 |
|-----------------------------------|--------------------------|
| `currencyExchangeService`         | `CurrencyExchangeService`|
| `signatureVerificationService`    | `SignatureService`       |
| `coreBankingSystemUpdater`        | `BankingSystemUpdater`   |
| `chequeHistoryManager`            | `ChequeHistoryManager`   |
| `fraudDetectionService`           | `FraudDetectionService`  |
| `exceptionReportManager`          | `ExceptionReportManager` |
| `chequeStatusManager`             | `ChequeStatusManager`    |
| `emailNotificationService`        | `NotificationService`    |

### `User` (Class)
| **Field**     | **Type** |
|---------------|----------|
| `username`    | `String` |
| `password`    | `String` |
| `role`        | `String` |

### `UserService` (Class)
| **Field** | **Type**         |
|-----------|------------------|
| `users`   | `List<User>`     |

### `ChequeStatus` (Enum)
| **Enum Value** | **Description**                  |
|----------------|----------------------------------|
| `ISSUED`       | Cheque has been issued.          |
| `PROCESSED`    | Cheque has been processed.       |
| `CANCELED`     | Cheque has been canceled.        |

### `ExceptionReportManager` (Class)
| **Field**       | **Type**  |
|------------------|-----------|
| `exceptions`     | `List<String>` |

### `ChequeImageHandler` (Class)
(No fields defined)

### `CryptographyService` (Class)
(No fields defined)

### `CurrencyExchangeService` (Class)
| **Field**               | **Type**  |
|--------------------------|-----------|
| `exchangeRateCache`      | `Map`     |
| `BASE_CURRENCY`          | `String`  |
| `CACHE_EXPIRY_MINUTES`   | `int`     |
| `API_KEY`                | `String`  |
| `FALLBACK_RATES`         | `Map`     |

### `FraudDetectionService` (Class)
| **Field**              | **Type**  |
|-------------------------|-----------|
| `fraudDetection`        | `Object`  |
| `historyManager`        | `Object`  |
| `recentTransactions`    | `List`    |

### `AdminService` (Class)
| **Field**           | **Type**  |
|----------------------|-----------|
| `ifscToBankCode`     | `Map`     |
| `bankCodeToName`     | `Map`     |
| `batches`            | `List`    |
| `stuckTransactions`  | `List`    |

---

## Error Conditions

| **Scenario**                                       | **Exception**                               | **Expected Handling**                                                                                                      |
|----------------------------------------------------|---------------------------------------------|---------------------------------------------------------------------------------------------------------------------------|
| Invalid login credentials                          | `SecurityException`                         | Notify the user and retry up to the maximum limit. Lock the account after exceeding retry limit.                           |
| Batch processing failure for a cheque             | `ProcessingException`                       | Log the error for the specific cheque, skip to the next cheque, and notify the user.                                       |
| Failure in currency exchange API call             | `IOException`, `ApiException`               | Fallback to predefined rates and warn the user.                                                                            |
| Missing or invalid cheque encryption keys         | `KeyManagementException`                    | Show a user-friendly error message and log details for admin review.                                                      |
| Fraudulent activity detected                      | `FraudDetectionException`                   | Mark the transaction as unprocessed, notify the user, and escalate to admin.                                               |
| Unexpected runtime exception                      | `RuntimeException`                          | Log details and notify the admin team. Retry if applicable, or fail gracefully.                                            |

---

## Migration Notes

1. **Checked Exceptions**: Convert Java checked exceptions (like `IOException`) to Python idiomatic exception handling (`try-except`).
2. **Null Handling**: Replace Java's `null` checks with Python's `None` checks and better use conditional expressions.
3. **Static State**: Replace static methods or variables with Python's class-level methods or modules.
4. **Instanceof Chains**: Simplify Java `instanceof` chains using Python's `isinstance` function and duck typing.
5. **Raw Types**: Handle Java raw collections like `List` by explicitly using Python's `list` or typing annotations like `List[Type]`.
6. **Threads and Synchronization**: Java `Thread` or `synchronized` blocks need to be mapped to Python’s `threading` or `asyncio` modules.
7. **External API Calls**: Refactor Java API calls (`HttpURLConnection`) to Python equivalents (e.g., `requests` library).
8. **Date/Time Handling**: Replace Java's `LocalDate` and `DateTimeFormatter` with Python's `datetime` and `timedelta` modules.
9. **I/O Operations**: Replace Java's `Files.readAllBytes()` with Python's `open(...)` and `read()` idioms.

---
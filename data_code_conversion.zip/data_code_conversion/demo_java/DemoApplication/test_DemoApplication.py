import pytest
from unittest.mock import MagicMock, call
from datetime import datetime, timedelta
from DemoApplication.services import CurrencyExchangeService, FraudDetectionService, SignatureVerificationService
from DemoApplication.cheque_processor import ChequeProcessor
from DemoApplication.user import User, UserService
from DemoApplication.admin_service import AdminService
from DemoApplication.batch_cheque import BatchCheque
from DemoApplication.enum_constants import ChequeStatus
from DemoApplication.report_manager import ExceptionReportManager
from demo_application import (perform_login, display_currency_exchange_menu, 
                              process_cheque_batch, handle_admin_tools, log_error)


@pytest.fixture
def user_service():
    """Fixture: Provides an initialized UserService for testing."""
    return UserService(users=[
        User(username="admin", password="admin123", role="admin"),
        User(username="user", password="user123", role="user")
    ])


@pytest.fixture
def currency_exchange_service():
    """Fixture: Provides an initialized CurrencyExchangeService for testing."""
    return CurrencyExchangeService(
        exchangeRateCache={},
        BASE_CURRENCY="USD",
        CACHE_EXPIRY_MINUTES=30,
        API_KEY="test_api_key",
        FALLBACK_RATES={"USD": 1.0, "EUR": 0.85}
    )


@pytest.fixture
def cheque_processor():
    """Fixture: Creates a ChequeProcessor for testing cheque processing logic."""
    return ChequeProcessor(
        currencyExchangeService=MagicMock(),
        signatureVerificationService=MagicMock(),
        coreBankingSystemUpdater=MagicMock(),
        chequeHistoryManager=MagicMock(),
        fraudDetectionService=MagicMock(),
        exceptionReportManager=ExceptionReportManager(exceptions=[]),
        chequeStatusManager=MagicMock(),
        emailNotificationService=MagicMock()
    )


@pytest.fixture
def admin_service():
    """Fixture: Provides an initialized AdminService for testing."""
    return AdminService(
        ifsc_to_bank_code={"123456": "BANK123"},
        bank_code_to_name={"BANK123": "Test Bank"},
        batches=[],
        stuck_transactions=[]
    )


@pytest.fixture
def exception_report_manager():
    """Fixture: Provides an initialized ExceptionReportManager for error handling."""
    return ExceptionReportManager(exceptions=[])


@pytest.mark.parametrize("username, password, expected_role", [
    ("admin", "admin123", "admin"),
    ("user", "user123", "user"),
    ("nonexistent", "wrongpassword", None)
])
def test_perform_login(user_service, username, password, expected_role):
    """Test: Authenticate the user based on username and password."""
    scanner = iter([username, password])  # Simulate scanner input
    user = perform_login(scanner, user_service)
    if expected_role is None:
        assert user is None
    else:
        assert user.role == expected_role


@pytest.mark.parametrize("cached_rates, expired, input_currency, expected_rate", [
    ({"USD_EUR": (0.85, datetime.now())}, False, "EUR", 0.85),
    ({}, True, "USD", 1.0),
])
def test_display_currency_exchange_menu(cached_rates, expired, input_currency, expected_rate):
    """Test: Handles currency exchange menu and checks caching logic."""
    currency_exchange_service = MagicMock()
    currency_exchange_service.exchangeRateCache = cached_rates
    currency_exchange_service.is_cache_expired = MagicMock(return_value=expired)
    currency_exchange_service.get_rate = MagicMock(return_value=expected_rate)

    scanner = MagicMock()
    scanner.nextLine = MagicMock(return_value=input_currency)

    display_currency_exchange_menu(scanner, currency_exchange_service)

    currency_exchange_service.get_rate.assert_called_with(input_currency)
    if expired:
        currency_exchange_service.update_cache_if_expired.assert_called_once()


@pytest.mark.parametrize("cheques, expected_statuses", [
    (
        [
            BatchCheque(account_number="12345", cheque_number="54321", currency="USD", amount=1000.0, signature="valid_signature"),
            BatchCheque(account_number="67890", cheque_number="09876", currency="EUR", amount=2000.0, signature="valid_signature"),
        ],
        [ChequeStatus.PROCESSED, ChequeStatus.PROCESSED]
    ),
    (
        [
            BatchCheque(account_number="11111", cheque_number="22222", currency="USD", amount=1500.0, signature=None),
        ],
        [ChequeStatus.REJECTED]
    )
])
def test_process_cheque_batch(cheque_processor, cheques, expected_statuses):
    """Test: Processes a batch of cheques sequentially and updates statuses."""
    scanner = iter(cheques)
    process_cheque_batch(scanner, cheque_processor)

    for cheque, expected_status in zip(cheques, expected_statuses):
        cheque_processor.chequeStatusManager.update_status.assert_called_with(cheque, expected_status)


@pytest.mark.parametrize("fraud_detected, raise_exception", [
    (True, FraudDetectionService), 
    (False, None),
])
def test_fraud_detection_edge_case(fraud_detected, raise_exception, cheque_processor):
    """Test: Validates fraud detection logic with edge cases."""
    cheque_processor.fraudDetectionService.detect_fraud = MagicMock(return_value=fraud_detected)
    cheque = BatchCheque(account_number="99999", cheque_number="00001", currency="USD", amount=5000.0, signature="test_sig")
    if raise_exception:
      ...
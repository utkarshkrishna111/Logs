Here is the improved test file, combining and refining the functional tests and golden-master tests. Redundant tests are removed, trivial assertions are omitted, overlapping test cases are deduplicated, and gaps in edge-case coverage are addressed. 

I’ve added meaningful docstrings and ensured general test clarity.

```python
from decimal import Decimal
import pytest
from io import StringIO
from contextlib import redirect_stdout
from invoice_calculator import calc_subtotal, apply_discount, calc_vat, calc_total, print_invoice_summary
from models import Invoice, LineItem


MAX_DISCOUNT = Decimal("50.0")  # Assume a maximum allowable discount of 50%


@pytest.fixture
def sample_line_items():
    """Fixture providing a sample list of line items."""
    return [
        LineItem(product_code="P001", description="Item A", quantity=2, unit_price=Decimal("10.00")),
        LineItem(product_code="P002", description="Item B", quantity=1, unit_price=Decimal("20.00")),
        LineItem(product_code="P003", description="Item C", quantity=3, unit_price=Decimal("5.00")),
    ]


@pytest.fixture
def sample_invoice(sample_line_items):
    """Fixture providing a sample invoice."""
    return Invoice(
        invoice_number="INV123", 
        customer_id="C001", 
        items=sample_line_items, 
        discount_pct=Decimal("10.0"), 
        vat_rate=Decimal("20.0")
    )


def test_calc_subtotal(sample_invoice):
    """Test calc_subtotal computes the correct sum of (quantity × unit_price) for all items."""
    subtotal = calc_subtotal(sample_invoice)
    expected_subtotal = Decimal("55.00")  # (2*10 + 1*20 + 3*5)
    assert subtotal == expected_subtotal


@pytest.mark.parametrize(
    "subtotal, discount_pct, expected",
    [
        (Decimal("100.0"), Decimal("10.0"), Decimal("90.0")),  # 10% discount
        (Decimal("200.0"), Decimal("50.0"), Decimal("100.0")),  # Max allowable discount
        (Decimal("300.0"), Decimal("0.0"), Decimal("300.0")),  # No discount
    ]
)
def test_apply_discount_valid(subtotal, discount_pct, expected):
    """Test apply_discount computes the correct discounted amount for valid discount percentages."""
    assert apply_discount(subtotal, discount_pct) == expected


@pytest.mark.parametrize(
    "subtotal, discount_pct",
    [
        (Decimal("400.0"), Decimal("-5.0")),  # Negative discount
        (Decimal("500.0"), Decimal("55.0")),  # Discount exceeds max allowable percentage
    ]
)
def test_apply_discount_invalid(subtotal, discount_pct):
    """Test apply_discount raises ValueError for invalid discount percentages."""
    with pytest.raises(ValueError, match=".*invalid discount percentage.*"):
        apply_discount(subtotal, discount_pct)


@pytest.mark.parametrize(
    "amount, vat_rate, expected",
    [
        (Decimal("100.0"), Decimal("20.0"), Decimal("20.0")),  # 20% VAT
        (Decimal("200.0"), Decimal("10.0"), Decimal("20.0")),  # 10% VAT
        (Decimal("300.0"), Decimal("0.0"), Decimal("0.0")),    # No VAT
    ]
)
def test_calc_vat(amount, vat_rate, expected):
    """Test calc_vat computes the correct VAT amount for valid VAT rates."""
    assert calc_vat(amount, vat_rate) == expected


@pytest.mark.parametrize(
    "discount_pct, vat_rate, raises_exception",
    [
        (Decimal("10.0"), Decimal("20.0"), False),  # Valid inputs
        (Decimal("-5.0"), Decimal("20.0"), True),   # Invalid discount
        (Decimal("55.0"), Decimal("20.0"), True),   # Discount exceeds max allowable percentage
        (Decimal("10.0"), Decimal("-20.0"), True),  # Negative VAT rate
    ]
)
def test_calc_total(discount_pct, vat_rate, sample_line_items, raises_exception):
    """Test calc_total calculates the correct total or raises errors for invalid inputs."""
    invoice = Invoice(
        invoice_number="INV001",
        customer_id="C002",
        items=sample_line_items,
        discount_pct=discount_pct,
        vat_rate=vat_rate
    )

    if raises_exception:
        with pytest.raises(ValueError, match=".*invalid.*"):
            calc_total(invoice)
    else:
        expected_subtotal = Decimal("55.00")  # From `sample_line_items`
        discounted_amount = apply_discount(expected_subtotal, discount_pct)
        vat_amount = calc_vat(discounted_amount, vat_rate)
        expected_total = discounted_amount + vat_amount
        assert calc_total(invoice) == expected_total


@pytest.mark.parametrize(
    "invoice, expected_output",
    [
        (
            Invoice(
                invoice_number="INV127",
                customer_id="CUST5",
                items=[LineItem(product_code="P5", description="Product 5", quantity=1, unit_price=Decimal("100.00"))],
                discount_pct=Decimal("10.0"),
                vat_rate=Decimal("20.0"),
            ),
            (
                "Invoice Summary:\n"
                "Invoice Number: INV127\n"
                "Customer ID: CUST5\n"
                "Subtotal: $100.00\n"
                "Discounted Total: $90.00\n"
                "VAT: $18.00\n"
                "Grand Total: $108.00\n"
            ),
        ),
    ],
)
def test_print_invoice_summary(invoice, expected_output):
    """Test print_invoice_summary correctly outputs the formatted invoice summary."""
    with StringIO() as buf, redirect_stdout(buf):
        print_invoice_summary(invoice)
        output = buf.getvalue()
    assert output == expected_output
```
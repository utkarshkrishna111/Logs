# Migration Specification: `InvoiceCalculator` Module

## Overview

The `InvoiceCalculator` module provides utility methods for calculating the financial details of an invoice. It computes subtotals, applies discounts, calculates VAT, and determines the total amount owed. The module also supports generating a formatted invoice summary. To achieve this, it operates on two core data structures: `LineItem` and `Invoice`, which encapsulate the necessary invoice details. The system ensures proper validation of discount percentages and handles edge cases gracefully.

---

## Inputs & Outputs

| **Method**                  | **Parameters**                                                                                                                                     | **Return Type**     | **Side Effects**                                   |
|-----------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|---------------------|---------------------------------------------------|
| `calcSubtotal`              | `Invoice invoice` (object containing the list of `LineItem`s)                                                                                     | `BigDecimal`        | None                                              |
| `applyDiscount`             | `BigDecimal subtotal`, `BigDecimal discountPct`                                                                                                  | `BigDecimal`        | Throws `IllegalArgumentException` for invalid %  |
| `calcVAT`                   | `BigDecimal amount`, `BigDecimal vatRate`                                                                                                        | `BigDecimal`        | None                                              |
| `calcTotal`                 | `Invoice invoice` (object including discountPct and vatRate)                                                                                     | `BigDecimal`        | Throws `IllegalArgumentException` for invalid %  |
| `printInvoiceSummary`       | `Invoice invoice` (object including all invoice and line item details)                                                                           | `void`              | Output to standard console                       |

---

## Business Rules

1. **Subtotal Calculation**: The subtotal for an invoice must be calculated as the sum of `(quantity × unitPrice)` for all line items in the invoice.
2. **Discount Application**: Discounts must only be applied if the `discountPct` value is non-negative and does not exceed the maximum allowable discount (`MAX_DISCOUNT`).
3. **VAT Calculation**: VAT must be calculated as a percentage of the provided base amount, based on the specified VAT rate.
4. **Total Calculation**: The total must be computed by applying the discount to the subtotal, then adding the VAT amount.
5. **Invoice Summary**: The invoice summary must display all relevant details, including the grand total, formatted for readability.
6. **Exception Handling**: The module must ensure that inappropriate discount percentages (e.g., negative or overly high values) raise clear and actionable exceptions.

---

## Data Structures

### `LineItem` Class

| **Field Name**  | **Type**     | **Description**                          |
|-----------------|--------------|------------------------------------------|
| `productCode`   | `String`     | A unique code identifying the product.   |
| `description`   | `String`     | A description of the product.            |
| `quantity`      | `int`        | The quantity of the product purchased.   |
| `unitPrice`     | `BigDecimal` | The price per unit of the product.       |

---

### `Invoice` Class

| **Field Name**   | **Type**              | **Description**                                  |
|------------------|-----------------------|-------------------------------------------------|
| `invoiceNumber`  | `String`             | Unique identifier for the invoice.              |
| `customerId`     | `String`             | Unique identifier for the customer.             |
| `items`          | `List<LineItem>`     | List of line items included in the invoice.     |
| `discountPct`    | `BigDecimal`         | Discount percentage to be applied (if any).     |
| `vatRate`        | `BigDecimal`         | VAT rate to be applied to the total amount.     |

---

## Error Conditions

### Checked Exceptions

- **`IllegalArgumentException`**: Thrown by the `applyDiscount` and `calcTotal` methods in the following cases:
  1. If `discountPct` is negative.
  2. If `discountPct` exceeds the maximum allowable discount (`MAX_DISCOUNT`).

### Unchecked Exceptions

- **Boundary Violations**: The methods assume valid numerical inputs (e.g., integers and BigDecimals). Invalid inputs, such as null values, may cause unexpected runtime exceptions. These must be handled during migration into Python using explicit input validation or `ValueError`.

---

## Migration Notes

### Key Considerations for Python Migration

1. **Checked Exceptions**: Since Python does not have checked exceptions, the `IllegalArgumentException` handling in methods like `applyDiscount` and `calcTotal` must be converted to explicit runtime checks, followed by handling through `ValueError` or similar exceptions.

2. **Null Handling**: Java's `null` requires careful attention during migration, as Python uses `None`. Explicit checks for `None` must be implemented to avoid runtime errors.

3. **BigDecimal Equivalent**: Java's `BigDecimal` must be mapped to Python's `decimal.Decimal` for maintaining precision in financial calculations. All arithmetic operations must retain Decimal semantics to avoid floating-point issues.

4. **Lists and Iteration**: Java's `List<LineItem>` should be mapped to Python's `list`. The for-each loop used in `calcSubtotal` can be translated directly to Python's `for` loop.

5. **Console Output**: Replace Java's `System.out.println` and `System.out.printf` with Python's `print` and string formatting using f-strings for readability and modern Python idioms.

6. **Stateless Methods**: Ensure all methods remain stateless and free of side effects (outside of console output) when migrating.

7. **Static Behavior**: Evaluate if static methods in Java (such as the utility methods in `InvoiceCalculator`) should be replaced by standalone functions in Python, or refactored into a class-based implementation if additional state management becomes necessary.

8. **Type Annotations**: Python 3 supports type annotations. Use them to replicate Java's strong typing (e.g., `def calcSubtotal(invoice: Invoice) -> Decimal`).

---

With these guidelines, the `InvoiceCalculator` module can be cleanly migrated to Python while preserving its functionality, ensuring numerical accuracy, and taking advantage of Python’s modern features.